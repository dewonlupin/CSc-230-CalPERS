<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 1000px; padding: 20px; }
    </style>
</head>
<body>
    <div class="wrapper">
      <p>
        An email has been sent to your Email for verification.
      </p>

    </div>
</body>
</html>
